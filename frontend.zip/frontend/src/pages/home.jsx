
import { Link } from "react-router-dom";
import {
  FiArrowRight,
  FiTruck,
  FiShield,
  FiHeadphones,
} from "react-icons/fi";
import Navbar from "../components/navbar";

const collections = [
  {
    name: "Living Room",
    description: "Comfort made beautiful.",
    image:
      "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=900&q=85",
    category: "Living",
  },
  {
    name: "Bedroom",
    description: "Your personal sanctuary.",
    image:
      "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=900&q=85",
    category: "Bed Room",
  },
  {
    name: "Dining Room",
    description: "Made for meaningful moments.",
    image:
      "https://images.unsplash.com/photo-1617806118233-18e1de247200?auto=format&fit=crop&w=900&q=85",
    category: "Dining",
  },
];

const benefits = [
  {
    icon: FiTruck,
    title: "Islandwide Delivery",
    text: "Furniture delivered to your door.",
  },
  {
    icon: FiShield,
    title: "Quality You Can Trust",
    text: "Thoughtful designs, made to last.",
  },
  {
    icon: FiHeadphones,
    title: "Here to Help",
    text: "We're here whenever you need us.",
  },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-[#F8F5F0] text-[#29251F]">
      <section className="relative h-[3px] w-full overflow-hidden sm:h-[100px]">
      <Navbar />
      </section>
      {/* HERO SECTION */}
      <section className="px-4 pb-8 pt-4 sm:px-6 lg:px-8 lg:pt-6">
        <div
          className="relative flex min-h-[490px] items-center justify-center object-contaion
          overflow-hidden rounded-[28px] bg-cover bg-center sm:min-h-[570px]
          lg:min-h-[650px]"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=2200&q=90')",
              backgroundPosition: "center",
  backgroundSize: "cover",
   backgroundPosition: "center 45%",
          }}
        >
          {/* Dark overlay */}
          <div className="absolute inset-0 bg-black/45" />

          {/* Subtle gradient */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/35 via-black/10 to-black/20" />

          <div className="relative z-10 mx-auto max-w-4xl px-5 py-16 text-center sm:px-10">
            <p className="mb-5 text-xs font-bold uppercase tracking-[0.3em] text-[#F4D6A0] sm:text-sm">
              A home you'll love
            </p>

            <h1 className="text-4xl font-bold leading-[1.12] tracking-tight text-white sm:text-5xl lg:text-7xl">
              Make room for
              <span className="mt-2 block font-serif font-medium italic text-[#F4D6A0]">
                beautiful living.
              </span>
            </h1>

            <p className="mx-auto mt-6 max-w-2xl text-base leading-7 text-white/85 sm:text-lg sm:leading-8">
              Discover furniture that feels like you. Thoughtfully selected
              pieces to make every corner of your home feel special.
            </p>

            <div className="mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link
                to="/products"
                className="group inline-flex min-h-14 items-center justify-center
                gap-3 rounded-2xl bg-[#B45309] px-8 py-4 text-sm font-semibold
                text-white shadow-lg shadow-black/10 transition-all duration-300
                hover:-translate-y-1 hover:bg-[#92400E] hover:shadow-xl"
              >
                Shop Furniture
                
              </Link>

              <Link
                to="/collections"
                className="inline-flex min-h-14 items-center justify-center
                rounded-2xl border border-white/60 bg-white/10 px-8 py-4
                text-sm font-semibold text-white backdrop-blur-sm transition
                hover:bg-white hover:text-[#29251F]"
              >
                Explore Collections
              </Link>
            </div>

            <div className="mt-10 flex items-center justify-center gap-3 text-xs text-white/75 sm:text-sm">
              <span className="h-px w-8 bg-[#F4D6A0]" />
              Thoughtful design. Everyday comfort.
              <span className="h-px w-8 bg-[#F4D6A0]" />
            </div>
          </div>

          <div className="absolute bottom-0 left-0 h-1 w-full bg-white/10">
            <div className="h-full w-1/3 bg-[#B45309]" />
          </div>
        </div>
      </section>

      {/* BENEFITS */}
      <section className="mx-auto max-w-7xl px-5 py-10 sm:px-8 lg:py-14">
        <div className="grid gap-8 border-b border-[#E6DED3] pb-10 sm:grid-cols-3 sm:gap-5">
          {benefits.map(({ icon: Icon, title, text }) => (
            <div key={title} className="flex items-center gap-4 sm:justify-center">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white text-[#A34D13] shadow-sm">
                <Icon size={22} />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#29251F] sm:text-base">
                  {title}
                </h3>
                <p className="mt-1 text-sm leading-6 text-[#81776B]">
                  {text}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* COLLECTIONS */}
      <section className="mx-auto max-w-7xl px-5 pb-20 sm:px-8 lg:pb-28">
        <div className="mb-9 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <p className="mb-3 text-xs font-bold uppercase tracking-[0.25em] text-[#A34D13]">
              Find your style
            </p>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
              Spaces to fall in love with.
            </h2>
            <p className="mt-3 max-w-xl text-sm leading-7 text-[#81776B] sm:text-base">
              From slow mornings to evenings with friends, find furniture for
              the moments that make a house your home.
            </p>
          </div>

          <Link
            to="/products"
            className="group inline-flex w-fit items-center gap-2 pb-1 text-sm font-semibold text-[#92400E]"
          >
            View all furniture
          </Link>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {collections.map((collection, index) => (
            <Link
              key={collection.name}
              to="/products"
              state={{ category: collection.category }}
              className="group overflow-hidden rounded-[24px] bg-white shadow-sm transition duration-500 hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="relative h-[300px] overflow-hidden sm:h-[340px]">
                <img
                  src={collection.image}
                  alt={collection.name}
                  loading="lazy"
                  className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/5 to-transparent" />
                <span className="absolute left-5 top-5 flex h-9 w-9 items-center justify-center rounded-full border border-white/50 bg-white/20 text-sm text-white backdrop-blur-sm">
                  0{index + 1}
                </span>
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white">
                      {collection.name}
                    </h3>
                    <p className="mt-2 text-sm text-white/80">
                      {collection.description}
                    </p>
                  </div>
                  
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* BRAND STORY */}
      <section className="border-y border-[#E9E0D5] bg-[#F0E9DF]">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-5 py-14 sm:px-8 md:grid-cols-2 lg:gap-20 lg:py-20">
          <div className="overflow-hidden rounded-[24px]">
            <img
              src="https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?auto=format&fit=crop&w=1600&q=90"
              alt="Warm and thoughtfully designed living space"
              loading="lazy"
              className="h-[300px] w-full object-cover sm:h-[420px]"
            />
          </div>

          <div className="py-2">
            <p className="mb-4 text-xs font-bold uppercase tracking-[0.25em] text-[#A34D13]">
              More than furniture
            </p>
            <h2 className="text-3xl font-bold leading-tight tracking-tight sm:text-4xl lg:text-5xl">
              Your home should feel like
              <span className="font-serif font-medium italic text-[#A34D13]">
                {" "}you.
              </span>
            </h2>
            <p className="mt-5 text-base leading-8 text-[#71685E]">
              At FurniLK, we believe the right furniture does more than fill a
              room. It creates a place to relax, connect, celebrate and make
              memories. Discover pieces that bring comfort and character into
              your everyday life.
            </p>
            <Link
              to="/products"
              className="group mt-7 inline-flex items-center gap-3 rounded-xl bg-[#B45309] px-6 py-4 text-sm font-semibold text-white transition hover:bg-[#92400E]"
            >
              Discover FurniLK
            </Link>
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="relative mx-auto max-w-7xl overflow-hidden rounded-[28px] bg-[#29251F] px-6 py-14 text-center sm:px-12 sm:py-20">
          <div
            className="absolute inset-0 bg-cover bg-center opacity-20"
            style={{
              backgroundImage:
                "url('https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1600&q=80')",
            }}
          />
          <div className="relative">
            <p className="mb-4 text-xs font-bold uppercase tracking-[0.25em] text-[#F4D6A0]">
              A home you'll love
            </p>
            <h2 className="mx-auto max-w-3xl text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl">
              Ready to make your space feel different?
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-sm leading-7 text-white/70 sm:text-base">
              Find the pieces that make your space feel like home.
            </p>
            <Link
              to="/products"
              className="group mt-8 inline-flex items-center gap-3 rounded-2xl bg-[#B45309] px-8 py-4 text-sm font-semibold text-white transition hover:bg-[#92400E]"
            >
              Shop Furniture
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
